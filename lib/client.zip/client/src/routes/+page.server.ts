import {httpRequest} from "$lib/http/httpRequest";
import type {Todo} from "$lib/api/fetchTodos";

const todosResponse = await httpRequest<Todo[], undefined>("/api/todos", "GET")

export const load = (() => {
  return {
    todos: structuredClone(todosResponse.data ? todosResponse.data : [])
  };
})