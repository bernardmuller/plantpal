<!--export const prerender = true;-->
<script>
    import {createQuery, useQueryClient} from '@tanstack/svelte-query'
    import {fetchTodos} from "../lib/api/fetchTodos";
    import {Button} from "$lib/components/ui/button";
    import {Skeleton} from "$lib/components/ui/skeleton";

    export let data
    const queryClient = useQueryClient()
    const todosQuery = createQuery({
        queryKey: ['todos'],
        queryFn: () => fetchTodos(),
        initialData: data.todos
    })
</script>


<div class="w-full flex justify-between">
    <h1>Welcome to SvelteKit</h1>
    <Button
            on:click={() => {
                queryClient.invalidateQueries(['todos'])
            }}
    >
        Log in
    </Button>
</div>
<div>
    {#if $todosQuery.isFetching}
        <div class="flex flex-col gap-4">
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
            <Skeleton class="w-[350px] h-8"/>
        </div>
    {:else if $todosQuery.isError}
        <p>Error: {$todosQuery.error.message}</p>
    {:else if $todosQuery.isSuccess}
        {#each $todosQuery.data as todo}
            <div class="flex gap-4">
                <p class="font-semibold">{todo.id}</p>
                <p>{todo.title}</p>
                <p class={todo.completed ? `text-green-300` : "text-stone-400" }>{todo.completed ? "Done" : "To Do"}</p>
            </div>
        {/each}
    {/if}
</div>
